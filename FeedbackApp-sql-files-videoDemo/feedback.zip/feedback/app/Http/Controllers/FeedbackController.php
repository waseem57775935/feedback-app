<?php

namespace App\Http\Controllers;
use App\Models\Feedback;
use App\Models\Comment;
use Illuminate\Support\Facades\Auth;


use Illuminate\Http\Request;

class FeedbackController extends Controller
{   
    public function feeback()
    {  
       $feedback = Feedback::with('comments')->orderBy('id', 'desc')->paginate(5);
       return view('welcome', ['feedback' => $feedback]);
    }

    public function create()
        {
            return view('feedback.create');
        }

        public function store(Request $request)
        {
            $validatedData = $request->validate([
                'title' => 'required|max:255',
                'description' => 'required',
                'category' => 'required|max:255',
            ]);

            $feedback = new Feedback;
            $feedback->user_id = Auth::id();
            $feedback->title = $validatedData['title'];
            $feedback->description = $validatedData['description'];
            $feedback->category = $validatedData['category'];
            $feedback->save();

            return redirect('/')->with('success', 'Feedback submitted successfully');
        }


        // Comments Functions

        public function AddComments(Request $request)
        {
            $validatedData = $request->validate([
                'feedback_id' => 'required',
                'comment' => 'required',
            ]);



            $comment = new Comment;
            $comment->feedback_id = $validatedData['feedback_id'];
            $comment->user_id = Auth::id();
            $comment->comment = $validatedData['comment'];
            $comment->save();

            return redirect('/')->with('success', 'Comment submitted successfully');
        }


        public function DeleteFeedback($id)
            {
                // Find the feedback by its ID
                $feedback = Feedback::find($id);

                if (!$feedback) {
                    return redirect()->route('users.feedback')->with('error', 'Feedback not found');
                }

                // Delete the feedback
                $feedback->delete();

                return redirect()->route('users.feedback')->with('success', 'Feedback deleted successfully');
            }

            public function DeleteComment($id)
                {
                    // Find the comment by its ID
                    $comment = Comment::find($id);

                    if (!$comment) {
                        return redirect()->route('users.feedback')->with('error', 'Comment not found');
                    }

                    // Delete the comment
                    $comment->delete();

                    return redirect()->route('users.feedback')->with('success', 'Comment deleted successfully');
                }
                public function updateCommentStatus($id)
                {
                    $feedback = Feedback::find($id);
                
                    if (!$feedback) {
                        return redirect()->route('users.feedback')->with('error', 'Feedback not found');
                    }
                
                    $commentStatus = request('commentstatus'); // Assuming 'commentstatus' is the name attribute of the checkbox
                
                    $feedback->cstatus = $commentStatus ? 'enable' : 'disable';
                    $feedback->save();
                
                    return redirect()->route('users.feedback')->with('success', 'Comment status updated successfully');
                }
                


}
