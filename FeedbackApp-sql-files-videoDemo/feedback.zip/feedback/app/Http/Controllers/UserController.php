<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Feedback;
use App\Models\Comment;

class UserController extends Controller
{
    public function index()
    {
        $users = User::paginate(10);

        return view('users.index', compact('users'));
    }

    public function feedbacks()
    {
        $feedbacks = Feedback::with('comments')->paginate(10);

        return view('feedback', compact('feedbacks'));
    }

    
    public function DeleteUser($id)
        {
            // Find the comment by its ID
            $user = User::find($id);

            if (!$user) {
                return redirect()->route('users.index')->with('error', 'Comment not found');
            }

            // Delete the comment
            $user->delete();

            return redirect()->route('users.index')->with('success', 'Comment deleted successfully');
        }
    
}
